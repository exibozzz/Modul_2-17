    <?php

        $baza = mysqli_connect("localhost","root","","web_shop");
        

    ?>