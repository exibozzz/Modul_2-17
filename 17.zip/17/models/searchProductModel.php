<?php


        if(!isset($_POST['search']) || empty($_POST['search'])) {
            die("You need to insert search value.");
        }

        require_once "baza.php";

        $searchProduct = $_POST['search'];

        $checkProducts = $baza->query(" SELECT * FROM products WHERE name LIKE '%$searchProduct%' OR description LIKE '%$searchProduct%' ");

        $foundedProductsInfo = $checkProducts->fetch_all(MYSQLI_ASSOC);


        if($checkProducts->num_rows <1)
        {

            echo "No product founded.";

        }


        $results = "Results:<br><br>";

        foreach($foundedProductsInfo as $productInfo)
        {

             $results .= $productInfo["name"]."<br>";

        }

        echo $results;



     

        
?>
