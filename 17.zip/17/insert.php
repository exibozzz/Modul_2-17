<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Insert Product</title>
        <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
        <script src="js/bootstrap.min.js"></script>
        <link rel="stylesheet" type="text/css" href="css/style.css">
    </head>


    <body>
        <form class="d-flex align-items-center justify-content-center flex-column bg-secondary col-12" method="POST" action="models/insertProductModel.php" >
            <p class="display-4 mt-1">Insert Product</p>
            <input class="form-control mb-3 col-5" type="text" name="name" placeholder="Enter the name of the product" required>
            <input class="form-control mb-3 col-5" type="text" name="description" placeholder="Enter descripion of the product" required>
            <input class="form-control mb-3 col-5" type="number" name="price" placeholder="Enter the price of the product" required>
            <input class="form-control mb-3 col-5" type="date" name="procurementDate" placeholder="Enter the day of product acquisition" required>
            <input class="form-control mb-3 col-5" type="number" name="amount" placeholder="Enter the amount of the product" required>
            <button class="btn btn-success mb-3 border border-white col-1">Insert</button>
        </form>   







    </body>
</html>