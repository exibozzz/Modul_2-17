<?php

        if(!isset($_GET['id']) || empty($_GET['id']))
        {
            die("Id product missing.");
        }

        var_dump ($_GET['id']);



        require_once "models/baza.php";

        $idProduct = $_GET['id'];

        $checkId = $baza->query("SELECT * FROM products WHERE id = $idProduct");

        $productAssocInfo = $checkId->fetch_assoc();

        var_dump($productAssocInfo);

        

?>


<!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title><?=$productAssocInfo['name']?></title>
            <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
            <script src="js/bootstrap.min.js"></script>
            <link rel="stylesheet" type="text/css" href="css/style.css">
            
        </head>


        <body>
            <h1><?=$productAssocInfo['name']?></h1>
            <p><?=$productAssocInfo['description']?></p>
            <p><?=$productAssocInfo['price']?></p>
            <p><?=$productAssocInfo['procurement_date']?></p>
            <p><?=$productAssocInfo['amount']?></p>  


            <!--GPT -> Create with this data in bootstrap 5 animated card based on style like online web store -->
            
            <div class="container mt-5">
            <div class="row justify-content-center">
            <div class="col-md-6">
                    <div class="card">
                        <img src="https://via.placeholder.com/500x300" class="card-img-top" alt="Product Image">
                        <div class="card-body">
                            <h5 class="card-title"><?= htmlspecialchars($productAssocInfo['name']) ?></h5>
                            <p class="card-text"><?= htmlspecialchars($productAssocInfo['description']) ?></p>
                            <p class="card-text"><strong>Price:</strong> $<?= htmlspecialchars($productAssocInfo['price']) ?></p>
                            <p class="card-text"><strong>Procurement Date:</strong> <?= htmlspecialchars($productAssocInfo['procurement_date']) ?></p>
                            <p class="card-text"><strong>Amount:</strong> <?= htmlspecialchars($productAssocInfo['amount']) ?></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        </body>
        </html>