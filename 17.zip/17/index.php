<?php

         require_once "models/baza.php";

         $products = $baza->query("SELECT * FROM products");

         $assocProducts = $products->fetch_all(MYSQLI_ASSOC);

         if(session_status() == PHP_SESSION_NONE)
         {
            session_start();
         }

?>



<!DOCTYPE html>

        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>All Products</title>
            <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
            <script src="js/bootstrap.min.js"></script>
            <link rel="stylesheet" type="text/css" href="css/style.css">
        </head>
        <body>

    

        <div class="container py-5">
        <div class="d-flex justify-content-between mb-4">
        <a href="index.php" class="btn btn-outline-primary">Home</a>
        <?php if(isset($_SESSION['logedInUser'])):?>
            <a href="logout.php" class="btn btn-outline-danger">Logout</a>
        <?php else: ?>
            <a href="login.php" class="btn btn-outline-success">Login</a>
        <?php endif; ?>
         </div>

         <div class="container">
         <h2 class="text-center text-dark mb-4">All Products</h2>
         <div class="row row-cols-1 row-cols-md-3 g-4">

            <?php foreach($assocProducts as $product): ?>
                <div class="col">
                    <div class="card h-100 shadow-sm">
                        <div class="card-body bg-primary text-white">
                            <h5 class="card-title"><?= htmlspecialchars($product['name']) ?></h5>
                            <p class="card-text"><?= htmlspecialchars($product['description']) ?></p>

                            <ul class="list-group list-group-flush">
                                <li class="list-group-item bg-primary text-white"><strong>Price:</strong> <?= htmlspecialchars($product['price']) ?></li>
                                <li class="list-group-item bg-primary text-white"><strong>Procurement Date:</strong> <?= htmlspecialchars($product['procurement_date']) ?></li>
                                <li class="list-group-item bg-primary text-white"><strong>Amount:</strong> <?= htmlspecialchars($product['amount']) ?></li>
                                <li class="list-group-item bg-primary text-white">
                                    <strong>Status:</strong> 
                                    <?php if($product['amount'] == 0): ?>
                                        <span class="badge bg-danger">N/A</span>
                                    <?php else: ?>
                                        <span class="badge bg-success">In Stock</span>
                                    <?php endif; ?>
                                </li>
                            </ul>

                        </div>

                        <div class="card-footer bg-light text-center">
                            <a href="product.php?id=<?= urlencode($product['id']) ?>" class="btn btn-dark">See Product</a>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>

        </div>
    </div>
</div>

</div>



        
            
        </body>
        </html>